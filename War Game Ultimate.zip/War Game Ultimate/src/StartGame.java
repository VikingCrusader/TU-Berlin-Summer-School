import javax.swing.*;

//Here to start the game!!!
public class StartGame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Lobby());
    }
}
