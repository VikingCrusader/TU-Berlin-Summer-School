package day2;

public class Ex2 {

	public static void main(String[] args) {
		long a, b;
		long c;
		a = 12375676;
		b = 73737;
		c = a * b;
		System.out.println(c);
		
		c = a / b;
		System.out.println(c);
		
		c = a * a * b * b;
		System.out.println(c);



	}

}
