package day2;

public class Ex15 {
	public static void main(String[] args) {
		int a = 12;
		switch (a) {
		case 5:
			System.out.println(a+" is five");
			break;
		case 7:
			System.out.println(a+" is seven");
			break;
		case 13:
			System.out.println(a+" is thirteen");
		default:
			System.out.println(a+" is twelve");
			break;
		}
	}
}
