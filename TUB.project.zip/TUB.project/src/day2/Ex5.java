package day2;

public class Ex5 {

	public static void main(String[] args) {
		String a, b, c;
		a = "This is my first program ";
		System.out.println(a);
		
		b = "in Java";
		
		c = a + b;
		
		System.out.println(c);

		System.out.println(c.length());
		System.out.println(c.lastIndexOf('i'));


	}

}
