package day2;

public class Ex12 {

	public static void main(String[] args) {
		int a, b, c;
		a = 10;
		b = 12;
		c = -12;
		if (a > b) {
			System.out.println("A is greater than B");

		} else {
			System.out.println("B is grater than A");

		}
	}

}
