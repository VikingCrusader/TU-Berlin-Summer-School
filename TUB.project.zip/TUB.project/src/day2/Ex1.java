package day2;

public class Ex1 {

	public static void main(String[] args) {
		
		// declare the variable
		byte a = 5;
		byte b = 6;
		byte c;
//		c = a + b;  can not execute byte + byte calculation
		
		int d, e, f;
		d = 6;
		e = 9;
		f = d + e;
		System.out.println(f);

		System.out.println(f / a);
		
		//CAUTION
		//divide by zero
		//divide by integer
		
	}

}
