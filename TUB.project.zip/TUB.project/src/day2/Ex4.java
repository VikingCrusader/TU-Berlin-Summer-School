package day2;

public class Ex4 {

	public static void main(String[] args) {
		// bitwise calculate
				int x, y, z;
				x = 11 & 9;
				y = x ^ 3;
				z = y | 12;
				System.out.println(x);
				System.out.println(y);
				System.out.println(z);

	}

}
