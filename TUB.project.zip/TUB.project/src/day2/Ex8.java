package day2;

public class Ex8 {
	public static void main(String[] args) {
		boolean a, b;
		
		a = true;
		b = false;
		
		boolean c = a & b;
		boolean d = a | b;
		boolean e = ! b;
		boolean g = a ^ b;
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(g);

	}
}
