package day3;

public class Ex3 {
	public static void main(String[] args) {
		// print numbers from 10 to 0
		int i = 10;
		while(i >= 0){
		System.out.println(i);
		i++;
		}
	}
}
