package day3;

public class Ex12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N = 100;
		for (int i = 1; i <= N; i++) {
			System.out.print(i+" ");
			if(i%4 == 0) {
				System.out.println(" ");
			}
		}
	}

}
