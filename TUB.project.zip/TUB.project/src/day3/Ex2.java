package day3;

public class Ex2 {
	public static void main(String[] args) {
		// print numbers from 10 to 0
		int i = 0;
		while(i <= 10){
			int n = 10 - i;
			System.out.println(n);
			i++;

		}
	}
}
