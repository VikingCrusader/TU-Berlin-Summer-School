package day3;

public class Ex1 {
	public static void main(String[] args) {
		// Print numnbers between 1 and 6.
		int i = 1;
		while (i<=6) {
			System.out.println(i);
			i++;   // index
		}
		
		for (int j = 7 ; j <= 10; j++) {
			System.out.println(j);
		}
	}
}
