package day3;

public class Ex15 {
	public static void main(String[] args) {
		boolean stop = true;
		int i = 0;
		while (true) {
			if ( i < 10) {
				stop = false;
			}
			i++;
			System.out.println(i);
		}
		// is also a infinite loop!!
		}
	
}
