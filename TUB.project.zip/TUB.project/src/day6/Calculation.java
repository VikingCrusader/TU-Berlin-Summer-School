package day6;

public class Calculation {
	double add (double a, double b) {
		return a + b;
	}
	
	double mul (double a, double b) {
		return a * b;
	}
}
