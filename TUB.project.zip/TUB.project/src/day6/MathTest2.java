package day6;

public class MathTest2 {
	Math1 obj1 = new Math (4.0)
}
