package day6;

public class MathTest1 {
	public static void main(String[] args) {
		Mathhhh obj1 = new Mathhhh (12.8, 7.9);
		System.out.println(obj1.add());
		System.out.println(obj1.mul());
		MathNew obj2 = new MathNew (12.8, 7.9);
		System.out.println(obj2.add());
		System.out.println(obj2.div());
		System.out.println(obj2.sub());
		System.out.println(obj2.mul());

	}

}
