package day6;

public class Mathhhh {
	double a;
	double b;
	public Mathhhh(double a, double b) {
		super();
		this.a = a;
		this.b = b;
	}
	public double add () {
		return this.a + this.b;
	}
	
	public double mul () {
		return this.a * this.b;
	}
}
