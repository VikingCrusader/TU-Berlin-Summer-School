package day6;

public abstract class Math2 extends Mathhhh {
	private double a;
	private double b;
	public Math2(double a, double b) {
		super(a, b);
		this.a = a;
		this.b = b;
	}
	public double getA() {
		return a;
	}
	public void setA(double a) {
		this.a = a;
	}
	public double getB() {
		return b;
	}
	public void setB(double b) {
		this.b = b;
	}
	
	//Uncompleted methods
	// TODO by otherone
	public abstract double MyDiv();
	
}
