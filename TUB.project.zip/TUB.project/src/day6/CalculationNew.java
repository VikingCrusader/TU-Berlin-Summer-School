package day6;

public class CalculationNew extends Calculation {
	double division (double a, double b) {
		return a / b;
	}
	
	double sub ( double a , double b) {
		return a - b;
	}
}
