package day5;

public class Ex3 {
	public static void main(String[] args) {
		toAbs(-10);
	}
	public static void toAbs (int n) {
		n = Math.abs(n);
		System.out.println(n);
	}
}
