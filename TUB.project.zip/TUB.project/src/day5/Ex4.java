package day5;

public class Ex4 {
	public static void main(String[] args) {
		System.out.println(toAbs(10));
	}
	public static int toAbs (int n) {
		n = Math.abs(n);
		return n;
	}
}
