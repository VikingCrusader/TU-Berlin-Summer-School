package day5;

public class Ex5 {
	public static void main(String[] args) {
		int arr [] = {1, 2, 3, 4, 5};
		printInt(arr);
	}
	public static void printInt (int arr[]) {
		for (int a : arr) {
			System.out.print(a + " ");
		}
	}
}
