package day8;
import java.util.ArrayList;
import java.util.HashMap;

public class Currency {
	String name;
	double rate;
	
	public Currency(String name, double rate) {
		super();
		this.name = name;
		this.rate = rate;
	}
	
	
	
	
}
