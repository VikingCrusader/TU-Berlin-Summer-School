package day8;

public class CurrencyTest {
	public static void main(String[] args) {
        Currency euro = new Currency ("Euro", 1.0);
        Currency yen = new Currency ("Yen", 170.76);
        Currency pound = new Currency ("Pound", 0.85);
	}
	
}
