package day8;

public class MeterTest {

	public static void main(String[] args) {
		meter obj1 = new meter ();
		String [] str = new String [10];
		obj1.toString();
		int a, b;
		a = 8;
		b = 9;
		a = a + b;
		
	}

}
