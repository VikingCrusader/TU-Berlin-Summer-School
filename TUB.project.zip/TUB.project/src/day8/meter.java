package day8;

public class meter {
	int size;
	String description;
	@Override
	public String toString() {
		return "meter [size=" + size + ", description=" + description + "]";
	}
	
	
}
