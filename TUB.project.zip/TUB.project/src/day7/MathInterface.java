package day7;

public interface MathInterface {
	public double add (double a, double b);
	public int add (int a, int b);
	public double mult (double a, double b);
	public int mult (int a, int b);
}

public class CalculationMethods implements MathInterface {

	@Override
	public double add(double a, double b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double mult(double a, double b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int mult(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}

public class CalculationMethodsD implements MathInterface {

	@Override
	public double add(double a, double b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double mult(double a, double b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int mult(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
