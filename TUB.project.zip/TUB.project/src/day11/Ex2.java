package day11;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Ex2 {

	public static void main(String[] args) {
		Collection <String >fruits = List.of("Apple", "Banana", "Orange");
		fruits.forEach(t -> System.out.println(t));
		
	}

}
