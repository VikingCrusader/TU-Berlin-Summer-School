package day11;

public class DaysOfTheWeek {
	public static void main(String[] args) {
		Days today = Days.WEDNESDAY;  // constant
		String today1 = "Wednesday";  
		System.out.println(today);
		
	}
}
