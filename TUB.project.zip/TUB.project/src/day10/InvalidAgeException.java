package day10;

// self created exception
public class InvalidAgeException extends Exception {
	public InvalidAgeException (String str) {
		super (str);
		
	}
}
