package day10;

public class Ex1 {

	public static void main(String[] args) {
		// input 2 variables
		int a, b, c;
		a = Integer.parseInt(args[0]);
		b = Integer.parseInt(args[1]);
		c = a / b;
		System.out.println(c);
	}

}
