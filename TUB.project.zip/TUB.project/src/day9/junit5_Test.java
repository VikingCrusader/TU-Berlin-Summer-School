package day9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

class junit5_Test {

	@Test
	@DisplayName("This is Surface Testing")
	@RepeatedTest(4000)
	void test() {
		fail("Not yet implemented");
	}

}
